// utils.js – shared helper functions for Hamza Fashion Embroidery

export const WHATSAPP_NUMBER = '03033331383';
export const WHATSAPP_INT_NUMBER = '923033331383'; // International format for wa.me links

/**
 * Hash a plain-text password using SHA-256 and return a hex string.
 * @param {string} password
 * @returns {Promise<string>} Hex-encoded hash
 */
export async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/** Simple localStorage helpers */
export function loadJSON(key) {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : null;
  } catch (e) {
    console.error(`Error loading ${key} from localStorage:`, e);
    return null;
  }
}

export function saveJSON(key, obj) {
  try {
    localStorage.setItem(key, JSON.stringify(obj));
  } catch (e) {
    console.error(`Error saving ${key} to localStorage:`, e);
  }
}

/** Generate a simple unique ID */
export function generateId(prefix = 'item') {
  return `${prefix}_` + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
}

/** Format a Date to a readable string */
export function formatDate(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return d.toLocaleDateString('en-PK', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

/**
 * Generate a direct WhatsApp click-to-chat URL with a pre-filled booking order message
 * @param {Object} booking
 * @returns {string} WhatsApp URL
 */
export function buildWhatsAppOrderUrl(booking) {
  const {
    customerName = 'Valued Customer',
    customerPhone = 'Not provided',
    address = 'Not provided',
    productTitle = 'Custom Embroidery Request',
    price = 'N/A',
    quantity = 1,
    size = 'Standard',
    notes = 'None'
  } = booking;

  const message = [
    `*NEW ORDER / BOOKING*`,
    `*Hamza Fashion Embroidery*`,
    `----------------------------------------`,
    `*Product:* ${productTitle}`,
    `*Price:* ${price}`,
    `*Quantity:* ${quantity}`,
    `*Size/Specification:* ${size}`,
    `----------------------------------------`,
    `*Customer Details:*`,
    `*Name:* ${customerName}`,
    `*Phone:* ${customerPhone}`,
    `*Delivery Address:* ${address}`,
    notes && notes !== 'None' ? `*Special Instructions:* ${notes}` : null,
    `----------------------------------------`,
    `Sent via Hamza Fashion Embroidery Online Booking`
  ].filter(Boolean).join('\n');

  return `https://wa.me/${WHATSAPP_INT_NUMBER}?text=${encodeURIComponent(message)}`;
}

/**
 * Direct WhatsApp chat URL for general inquiries
 */
export function getWhatsAppDirectChatUrl(initialMessage = 'Hello Hamza Fashion Embroidery! I want to inquire about your embroidery collection.') {
  return `https://wa.me/${WHATSAPP_INT_NUMBER}?text=${encodeURIComponent(initialMessage)}`;
}
