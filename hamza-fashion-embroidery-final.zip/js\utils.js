// utils.js – shared helper functions for Hamza Fashion Embroidery

export const WHATSAPP_NUMBER = '03033331383';
export const WHATSAPP_INT_NUMBER = '923033331383'; // International format for wa.me links

/**
 * Executes a callback reliably whether DOM has already loaded or is still loading.
 * Fixes issues where DOMContentLoaded already fired before ES Module loaded.
 */
export function runWhenReady(fn) {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fn, { once: true });
  } else {
    // DOM already loaded, execute immediately or on next tick
    setTimeout(fn, 0);
  }
}

/**
 * Hash a plain-text password using SHA-256 with fallback.
 * @param {string} password
 * @returns {Promise<string>} Hex-encoded hash
 */
export async function hashPassword(password) {
  try {
    if (window.crypto && window.crypto.subtle) {
      const encoder = new TextEncoder();
      const data = encoder.encode(password);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }
  } catch (e) {
    console.warn('crypto.subtle not available, using fallback hash');
  }

  // Fallback hash for non-HTTPS or unsupported environments
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return 'h_' + Math.abs(hash).toString(16);
}

/** Simple localStorage helpers */
export function loadJSON(key) {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : null;
  } catch (e) {
    console.error(`Error loading ${key} from localStorage:`, e);
    return null;
  }
}

export function saveJSON(key, obj) {
  try {
    localStorage.setItem(key, JSON.stringify(obj));
  } catch (e) {
    console.error(`Error saving ${key} to localStorage:`, e);
  }
}

/** Generate a simple unique ID */
export function generateId(prefix = 'item') {
  return `${prefix}_` + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
}

/** Format a Date to a readable string */
export function formatDate(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return d.toLocaleDateString('en-PK', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

/**
 * Generate a direct WhatsApp click-to-chat URL with a pre-filled booking order message
 * @param {Object} booking
 * @returns {string} WhatsApp URL
 */
export function buildWhatsAppOrderUrl(booking) {
  const {
    customerName = 'Valued Customer',
    customerPhone = 'Not provided',
    address = 'Not provided',
    productTitle = 'Custom Embroidery Request',
    price = 'N/A',
    quantity = 1,
    size = 'Standard',
    notes = 'None'
  } = booking;

  const message = [
    `*NEW ORDER / BOOKING*`,
    `*Hamza Fashion Embroidery*`,
    `----------------------------------------`,
    `*Product:* ${productTitle}`,
    `*Price:* ${price}`,
    `*Quantity:* ${quantity}`,
    `*Size/Specification:* ${size}`,
    `----------------------------------------`,
    `*Customer Details:*`,
    `*Name:* ${customerName}`,
    `*Phone:* ${customerPhone}`,
    `*Delivery Address:* ${address}`,
    notes && notes !== 'None' ? `*Special Instructions:* ${notes}` : null,
    `----------------------------------------`,
    `Sent via Hamza Fashion Embroidery Online Booking`
  ].filter(Boolean).join('\n');

  return `https://wa.me/${WHATSAPP_INT_NUMBER}?text=${encodeURIComponent(message)}`;
}

/**
 * Direct WhatsApp chat URL for general inquiries
 */
export function getWhatsAppDirectChatUrl(initialMessage = 'Hello Hamza Fashion Embroidery! I want to inquire about your embroidery collection.') {
  return `https://wa.me/${WHATSAPP_INT_NUMBER}?text=${encodeURIComponent(initialMessage)}`;
}
