// dashboard.js – Admin panel logic for managing live products and WhatsApp orders

import { getProducts, addProduct, updateProduct, deleteProduct, resetDefaultProducts, getOrders, deleteOrder } from './products.js';
import { currentUser, isAdmin, login, logout } from './auth.js';
import { WHATSAPP_NUMBER } from './utils.js';

let currentEditingId = null;

// Initialize Admin Dashboard
document.addEventListener('DOMContentLoaded', () => {
  initDashboard();
});

function initDashboard() {
  const adminApp = document.getElementById('adminApp');
  const adminLoginSection = document.getElementById('adminLoginSection');

  // Check auth
  if (!isAdmin()) {
    if (adminApp) adminApp.style.display = 'none';
    if (adminLoginSection) adminLoginSection.style.display = 'block';
    setupInlineAdminLogin();
    return;
  }

  // User is admin
  if (adminLoginSection) adminLoginSection.style.display = 'none';
  if (adminApp) adminApp.style.display = 'block';

  setupTabs();
  setupProductModal();
  setupLogout();
  refreshDashboard();
}

// Inline Login for Admin if not logged in
function setupInlineAdminLogin() {
  const form = document.getElementById('inlineAdminLoginForm');
  const alertBox = document.getElementById('inlineAdminAlert');

  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const user = document.getElementById('inlineUsername').value.trim();
    const pass = document.getElementById('inlinePassword').value.trim();

    const res = await login(user, pass);
    if (res.success && res.user.role === 'admin') {
      alertBox.textContent = 'Admin login successful!';
      alertBox.className = 'auth-alert success';
      alertBox.style.display = 'block';
      setTimeout(() => {
        initDashboard();
      }, 500);
    } else if (res.success && res.user.role !== 'admin') {
      alertBox.textContent = 'Access denied: You must be an administrator.';
      alertBox.className = 'auth-alert error';
      alertBox.style.display = 'block';
    } else {
      alertBox.textContent = res.message;
      alertBox.className = 'auth-alert error';
      alertBox.style.display = 'block';
    }
  });
}

function setupLogout() {
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      logout();
      window.location.reload();
    });
  }
}

// Tabs setup
function setupTabs() {
  const tabProducts = document.getElementById('tabProducts');
  const tabOrders = document.getElementById('tabOrders');
  const viewProducts = document.getElementById('viewProducts');
  const viewOrders = document.getElementById('viewOrders');

  if (!tabProducts || !tabOrders) return;

  tabProducts.addEventListener('click', () => {
    tabProducts.classList.add('active');
    tabOrders.classList.remove('active');
    viewProducts.style.display = 'block';
    viewOrders.style.display = 'none';
  });

  tabOrders.addEventListener('click', () => {
    tabOrders.classList.add('active');
    tabProducts.classList.remove('active');
    viewProducts.style.display = 'none';
    viewOrders.style.display = 'block';
    renderOrders();
  });
}

// Render Products Table & Stats
export function refreshDashboard() {
  const products = getProducts();
  const orders = getOrders();

  // Update Stats
  const statProducts = document.getElementById('statTotalProducts');
  const statOrders = document.getElementById('statTotalOrders');
  const badgeProductCount = document.getElementById('badgeProductCount');
  const badgeOrderCount = document.getElementById('badgeOrderCount');

  if (statProducts) statProducts.textContent = products.length;
  if (statOrders) statOrders.textContent = orders.length;
  if (badgeProductCount) badgeProductCount.textContent = products.length;
  if (badgeOrderCount) badgeOrderCount.textContent = orders.length;

  renderProductsTable(products);
}

function renderProductsTable(products) {
  const tbody = document.querySelector('#productsTable tbody');
  if (!tbody) return;

  tbody.innerHTML = '';

  if (products.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 2rem; color: #888;">No products found. Click "+ Add New Product" to list one on the website!</td></tr>`;
    return;
  }

  products.forEach((p, idx) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>#${idx + 1}</strong></td>
      <td>
        <img src="${p.img}" alt="${p.title}" class="product-thumb" onerror="this.src='./assets/product_placeholder.jpg'"/>
      </td>
      <td>
        <strong style="color: #111;">${escapeHtml(p.title)}</strong>
        <div style="font-size: 0.8rem; color: #777;">${escapeHtml(p.description || '').substring(0, 45)}...</div>
      </td>
      <td><span class="table-badge category">${escapeHtml(p.category)}</span></td>
      <td><strong style="color: var(--color-accent);">${p.price}</strong></td>
      <td>
        ${p.onSale ? '<span class="table-badge sale">SALE</span>' : '<span style="color:#aaa;">Standard</span>'}
        <div style="font-size:0.75rem; color:#ffb400; margin-top: 2px;">★ ${p.rating}/5</div>
      </td>
      <td>
        <div class="action-btns">
          <button class="action-btn edit" data-id="${p.id}" title="Edit Product">
            <i data-lucide="edit-2"></i> Edit
          </button>
          <button class="action-btn delete" data-id="${p.id}" title="Delete Product">
            <i data-lucide="trash-2"></i> Delete
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Attach Edit and Delete listeners
  tbody.querySelectorAll('.action-btn.edit').forEach(btn => {
    btn.addEventListener('click', () => {
      openEditModal(btn.dataset.id);
    });
  });

  tbody.querySelectorAll('.action-btn.delete').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      if (confirm('Are you sure you want to remove this product from the website?')) {
        deleteProduct(id);
        refreshDashboard();
      }
    });
  });

  if (window.lucide) window.lucide.createIcons();
}

function renderOrders() {
  const tbody = document.querySelector('#ordersTable tbody');
  if (!tbody) return;

  const orders = getOrders();
  tbody.innerHTML = '';

  if (orders.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 2rem; color: #888;">No customer bookings recorded yet. Once customers place orders through WhatsApp on the website, they will appear here!</td></tr>`;
    return;
  }

  orders.forEach((o, idx) => {
    const tr = document.createElement('tr');
    const waLink = `https://wa.me/${o.customerPhone ? o.customerPhone.replace(/[^\d]/g, '') : WHATSAPP_NUMBER}?text=${encodeURIComponent(`Hello ${o.customerName}, regarding your order for "${o.productTitle}" at Hamza Fashion Embroidery:`)}`;
    tr.innerHTML = `
      <td>#${idx + 1}</td>
      <td><strong>${escapeHtml(o.customerName || 'Customer')}</strong></td>
      <td>
        <a href="tel:${escapeHtml(o.customerPhone)}" style="color: #333; text-decoration: underline;">
          ${escapeHtml(o.customerPhone || 'N/A')}
        </a>
      </td>
      <td>
        <strong>${escapeHtml(o.productTitle)}</strong>
        <div style="font-size:0.8rem; color:#666;">Qty: ${o.quantity} | Size: ${o.size || 'Standard'}</div>
      </td>
      <td><span style="font-size:0.85rem; color:#555;">${escapeHtml(o.address || 'N/A')}</span></td>
      <td><span style="font-size:0.8rem; color:#888;">${o.date || 'Recent'}</span></td>
      <td>
        <div class="action-btns">
          <a href="${waLink}" target="_blank" class="action-btn whatsapp" title="Chat on WhatsApp">
            <i data-lucide="message-circle"></i> Chat
          </a>
          <button class="action-btn delete" data-order-id="${o.id}" title="Remove Order">
            <i data-lucide="trash"></i>
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });

  tbody.querySelectorAll('.action-btn.delete').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.orderId;
      if (confirm('Delete this order entry?')) {
        deleteOrder(id);
        renderOrders();
        refreshDashboard();
      }
    });
  });

  if (window.lucide) window.lucide.createIcons();
}

// Modal handling
function setupProductModal() {
  const modal = document.getElementById('productModal');
  const btnOpenAdd = document.getElementById('btnOpenAddProduct');
  const btnClose = document.getElementById('btnCloseModal');
  const btnCancel = document.getElementById('btnCancelModal');
  const form = document.getElementById('productForm');
  const btnResetDefaults = document.getElementById('btnResetDefaults');

  if (btnOpenAdd) {
    btnOpenAdd.addEventListener('click', () => {
      openAddModal();
    });
  }

  if (btnClose) btnClose.addEventListener('click', closeModal);
  if (btnCancel) btnCancel.addEventListener('click', closeModal);

  if (btnResetDefaults) {
    btnResetDefaults.addEventListener('click', () => {
      if (confirm('Reset store products back to original showcase items?')) {
        resetDefaultProducts();
        refreshDashboard();
      }
    });
  }

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const title = document.getElementById('prodTitle').value;
      const category = document.getElementById('prodCategory').value;
      const price = document.getElementById('prodPrice').value;
      const img = document.getElementById('prodImg').value;
      const rating = document.getElementById('prodRating').value;
      const onSale = document.getElementById('prodOnSale').checked;
      const description = document.getElementById('prodDesc').value;

      const payload = {
        title,
        category,
        price,
        img: img || './assets/product_placeholder.jpg',
        rating,
        onSale,
        description
      };

      if (currentEditingId) {
        updateProduct(currentEditingId, payload);
      } else {
        addProduct(payload);
      }

      closeModal();
      refreshDashboard();
    });
  }
}

function openAddModal() {
  currentEditingId = null;
  document.getElementById('modalTitle').textContent = 'Add New Product to Website';
  document.getElementById('productForm').reset();
  document.getElementById('prodImg').value = './assets/product_placeholder.jpg';
  document.getElementById('productModal').classList.add('open');
}

function openEditModal(id) {
  const products = getProducts();
  const product = products.find(p => p.id === id);
  if (!product) return;

  currentEditingId = id;
  document.getElementById('modalTitle').textContent = 'Edit Product';
  document.getElementById('prodTitle').value = product.title;
  document.getElementById('prodCategory').value = product.category;
  document.getElementById('prodPrice').value = product.price;
  document.getElementById('prodImg').value = product.img;
  document.getElementById('prodRating').value = product.rating;
  document.getElementById('prodOnSale').checked = Boolean(product.onSale);
  document.getElementById('prodDesc').value = product.description || '';

  document.getElementById('productModal').classList.add('open');
}

function closeModal() {
  const modal = document.getElementById('productModal');
  if (modal) modal.classList.remove('open');
  currentEditingId = null;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
