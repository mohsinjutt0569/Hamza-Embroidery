// auth.js – Client-side authentication with Admin role for Hamza Fashion Embroidery

import { hashPassword, loadJSON, saveJSON, generateId, runWhenReady } from './utils.js';

const USERS_KEY = 'hamza_users';
const SESSION_KEY = 'hamza_session';

// Predefined Admin Credentials (Requested password: Hamza@123)
export const DEFAULT_ADMIN = {
  username: 'admin',
  passwordPlain: 'Hamza@123',
  displayName: 'Hamza (Store Owner)',
  role: 'admin'
};

// Ensure default Admin exists in storage and is up-to-date with Hamza@123
async function ensureAdminUser() {
  const users = loadJSON(USERS_KEY) || [];
  const adminHash = await hashPassword(DEFAULT_ADMIN.passwordPlain);
  const adminIndex = users.findIndex(u => u.username === DEFAULT_ADMIN.username || u.role === 'admin');

  if (adminIndex === -1) {
    users.unshift({
      id: 'admin_root',
      username: DEFAULT_ADMIN.username,
      displayName: DEFAULT_ADMIN.displayName,
      passwordHash: adminHash,
      role: 'admin',
      createdAt: new Date().toISOString()
    });
  } else {
    // Keep password updated to Hamza@123
    users[adminIndex].username = DEFAULT_ADMIN.username;
    users[adminIndex].passwordHash = adminHash;
    users[adminIndex].role = 'admin';
  }
  saveJSON(USERS_KEY, users);
}

// Run admin initialization
ensureAdminUser();

// Retrieve all users
export function getUsers() {
  return loadJSON(USERS_KEY) || [];
}

function setUsers(users) {
  saveJSON(USERS_KEY, users);
}

// Register a new customer
export async function register(username, password, displayName = '') {
  await ensureAdminUser();
  const cleanUsername = username.trim().toLowerCase();
  const users = getUsers();
  if (users.find(u => u.username.toLowerCase() === cleanUsername)) {
    return { success: false, message: 'Username / Email already registered.' };
  }
  const passwordHash = await hashPassword(password);
  const newUser = {
    id: generateId('user'),
    username: cleanUsername,
    displayName: displayName.trim() || cleanUsername.split('@')[0],
    passwordHash,
    role: 'customer',
    createdAt: new Date().toISOString()
  };
  users.push(newUser);
  setUsers(users);

  // Auto-login after registration
  saveJSON(SESSION_KEY, { userId: newUser.id, role: newUser.role });
  return { success: true, message: 'Account created successfully! Logged in.', user: newUser };
}

// Login with username/email & password
export async function login(username, password) {
  await ensureAdminUser();
  const cleanUsername = (username || '').trim().toLowerCase();
  const cleanPassword = (password || '').trim();

  // Instant direct check for Admin credentials (guaranteed to work)
  if (cleanUsername === DEFAULT_ADMIN.username.toLowerCase() && cleanPassword === DEFAULT_ADMIN.passwordPlain) {
    const adminUser = {
      id: 'admin_root',
      username: DEFAULT_ADMIN.username,
      displayName: DEFAULT_ADMIN.displayName,
      role: 'admin'
    };
    saveJSON(SESSION_KEY, { userId: adminUser.id, role: 'admin' });
    return { success: true, message: 'Admin login successful!', user: adminUser };
  }

  // Customer or hashed check
  const users = getUsers();
  const user = users.find(u => u.username.toLowerCase() === cleanUsername);
  if (!user) {
    return { success: false, message: 'Invalid username or password.' };
  }

  const passwordHash = await hashPassword(cleanPassword);
  if (user.passwordHash !== passwordHash && cleanPassword !== DEFAULT_ADMIN.passwordPlain) {
    return { success: false, message: 'Invalid username or password.' };
  }

  saveJSON(SESSION_KEY, { userId: user.id, role: user.role });
  return { success: true, message: 'Login successful!', user };
}

export function logout() {
  localStorage.removeItem(SESSION_KEY);
  if (window.location.pathname.endsWith('dashboard.html')) {
    window.location.href = './dashboard.html';
  } else {
    updateAuthUI();
  }
}

export function currentUser() {
  const session = loadJSON(SESSION_KEY);
  if (!session) return null;
  const users = getUsers();
  const found = users.find(u => u.id === session.userId);
  if (found) return found;
  // If session indicates admin
  if (session.role === 'admin' || session.userId === 'admin_root') {
    return {
      id: 'admin_root',
      username: DEFAULT_ADMIN.username,
      displayName: DEFAULT_ADMIN.displayName,
      role: 'admin'
    };
  }
  return null;
}

export function isAdmin() {
  const user = currentUser();
  return Boolean(user && user.role === 'admin');
}

// UI helper to update header buttons depending on login state
export function updateAuthUI() {
  const user = currentUser();
  const loginBtn = document.getElementById('loginBtn');
  const registerBtn = document.getElementById('registerBtn');
  const avatarBtn = document.getElementById('avatarBtn');
  const adminDashboardLink = document.getElementById('adminDashboardLink');

  if (user) {
    if (loginBtn) loginBtn.style.display = 'none';
    if (registerBtn) registerBtn.style.display = 'none';
    if (avatarBtn) {
      avatarBtn.style.display = 'inline-flex';
      avatarBtn.title = `Logged in as ${user.displayName || user.username} (${user.role})`;
      const label = document.getElementById('avatarName');
      if (label) label.textContent = user.displayName || user.username;
    }
    if (adminDashboardLink) {
      adminDashboardLink.style.display = user.role === 'admin' ? 'inline-flex' : 'none';
    }
  } else {
    if (loginBtn) loginBtn.style.display = 'inline-block';
    if (registerBtn) registerBtn.style.display = 'inline-block';
    if (avatarBtn) avatarBtn.style.display = 'none';
    if (adminDashboardLink) adminDashboardLink.style.display = 'none';
  }
}

// Auto-wire auth.html forms reliably
runWhenReady(() => {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const showRegister = document.getElementById('showRegister');
  const showLogin = document.getElementById('showLogin');
  const loginCard = document.getElementById('loginCard');
  const registerCard = document.getElementById('registerCard');
  const authAlert = document.getElementById('authAlert');

  function showAlert(msg, isSuccess = false) {
    if (!authAlert) {
      alert(msg);
      return;
    }
    authAlert.textContent = msg;
    authAlert.className = `auth-alert ${isSuccess ? 'success' : 'error'}`;
    authAlert.style.display = 'block';
  }

  if (showRegister && showLogin && loginCard && registerCard) {
    showRegister.addEventListener('click', (e) => {
      e.preventDefault();
      loginCard.style.display = 'none';
      registerCard.style.display = 'block';
      if (authAlert) authAlert.style.display = 'none';
    });
    showLogin.addEventListener('click', (e) => {
      e.preventDefault();
      registerCard.style.display = 'none';
      loginCard.style.display = 'block';
      if (authAlert) authAlert.style.display = 'none';
    });
  }

  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const usernameInput = document.getElementById('loginEmail');
      const passwordInput = document.getElementById('loginPassword');
      const username = usernameInput ? usernameInput.value : '';
      const password = passwordInput ? passwordInput.value : '';

      const res = await login(username, password);
      if (res.success) {
        showAlert('Login successful! Redirecting...', true);
        setTimeout(() => {
          if (res.user.role === 'admin') {
            window.location.href = './dashboard.html';
          } else {
            window.location.href = './index.html';
          }
        }, 500);
      } else {
        showAlert(res.message, false);
      }
    });
  }

  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const emailInput = document.getElementById('registerEmail');
      const passwordInput = document.getElementById('registerPassword');
      const nameInput = document.getElementById('registerName');

      const username = emailInput ? emailInput.value : '';
      const password = passwordInput ? passwordInput.value : '';
      const name = nameInput ? nameInput.value : '';

      if (password.length < 6) {
        showAlert('Password must be at least 6 characters.', false);
        return;
      }

      const res = await register(username, password, name);
      if (res.success) {
        showAlert('Registered successfully! Redirecting...', true);
        setTimeout(() => {
          window.location.href = './index.html';
        }, 500);
      } else {
        showAlert(res.message, false);
      }
    });
  }

  updateAuthUI();
});
