// script.js – Core interactivity, dynamic products & WhatsApp booking for Hamza Fashion Embroidery

import { getProducts, recordOrder } from './products.js';
import { buildWhatsAppOrderUrl, WHATSAPP_NUMBER } from './utils.js';
import { updateAuthUI, currentUser, logout, isAdmin } from './auth.js';

let activeCategory = 'all';
let searchQuery = '';

// DOM Elements
const productGrid = document.getElementById('productGrid');
const suggestionGrid = document.getElementById('suggestionGrid');
const searchInput = document.getElementById('searchInput');
const currentCategoryTitle = document.getElementById('currentCategoryTitle');
const productCountSubtitle = document.getElementById('productCountSubtitle');
const categoryNav = document.getElementById('categoryNav');
const backToTopBtn = document.getElementById('backToTop');

// Booking Modal Elements
const bookingModal = document.getElementById('bookingModal');
const btnCloseBookingModal = document.getElementById('btnCloseBookingModal');
const bookingForm = document.getElementById('whatsappBookingForm');
const bookingModalHeading = document.getElementById('bookingModalHeading');
const bookingThumb = document.getElementById('bookingThumb');
const bookingTitle = document.getElementById('bookingTitle');
const bookingPrice = document.getElementById('bookingPrice');
const formProductId = document.getElementById('formProductId');
const formProductTitle = document.getElementById('formProductTitle');
const formProductPrice = document.getElementById('formProductPrice');
const btnOpenCustomBooking = document.getElementById('btnOpenCustomBooking');

// Initialize Storefront
document.addEventListener('DOMContentLoaded', () => {
  renderCatalog();
  renderSuggestions();
  setupCategoryFilters();
  setupSearch();
  setupBookingModal();
  setupScrollEffects();
  setupUserAuth();
});

/**
 * Filter and render products to the main product grid
 */
export function renderCatalog() {
  if (!productGrid) return;

  const allProducts = getProducts();
  let filtered = allProducts;

  // Filter by Category
  if (activeCategory !== 'all') {
    filtered = filtered.filter(p => p.category.toLowerCase() === activeCategory.toLowerCase());
  }

  // Filter by Search Query
  if (searchQuery.trim() !== '') {
    const q = searchQuery.toLowerCase().trim();
    filtered = filtered.filter(p =>
      p.title.toLowerCase().includes(q) ||
      (p.description && p.description.toLowerCase().includes(q)) ||
      p.category.toLowerCase().includes(q)
    );
  }

  // Update Section Header Subtitle
  if (productCountSubtitle) {
    productCountSubtitle.textContent = `Showing ${filtered.length} of ${allProducts.length} items in collection`;
  }

  // Clear Grid
  productGrid.innerHTML = '';

  if (filtered.length === 0) {
    productGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 3rem 1rem; color: #888;">
        <i data-lucide="package-search" style="width:48px; height:48px; margin-bottom:1rem; color:#bbb;"></i>
        <h3 style="color:#333; margin-bottom:0.5rem;">No products match your selection</h3>
        <p>Try searching for a different keyword or browse all categories.</p>
        <button id="btnResetSearch" style="margin-top:1rem; padding:0.5rem 1.2rem; background:var(--color-accent); color:#fff; border:none; border-radius:20px; font-weight:600; cursor:pointer;">
          View All Products
        </button>
      </div>
    `;
    const btnReset = document.getElementById('btnResetSearch');
    if (btnReset) {
      btnReset.addEventListener('click', () => {
        activeCategory = 'all';
        searchQuery = '';
        if (searchInput) searchInput.value = '';
        updateCategoryNavUI();
        renderCatalog();
      });
    }
    if (window.lucide) window.lucide.createIcons();
    return;
  }

  // Render Product Cards
  filtered.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';

    // Stars HTML
    let starsHtml = '';
    const rating = p.rating || 5;
    for (let i = 1; i <= 5; i++) {
      starsHtml += i <= rating ? '★' : '☆';
    }

    card.innerHTML = `
      <div class="product-card-img-wrap">
        <img src="${p.img}" alt="${escapeHtml(p.title)}" onerror="this.src='./assets/product_placeholder.jpg'"/>
        ${p.onSale ? '<span class="badge">SALE</span>' : ''}
        <span class="category-tag">${formatCategoryName(p.category)}</span>
      </div>

      <div class="product-info">
        <h3>${escapeHtml(p.title)}</h3>
        <p class="product-desc">${escapeHtml(p.description || 'Finest hand & machine embroidery on premium fabric.')}</p>

        <div class="price-row">
          <div class="price">${p.price}</div>
          <div class="rating" title="${rating} of 5 stars">${starsHtml}</div>
        </div>

        <div class="card-actions">
          <button class="btn-whatsapp-order" data-id="${p.id}" title="Order this product on WhatsApp">
            <i data-lucide="message-circle"></i> Order via WhatsApp
          </button>
        </div>
      </div>
    `;

    productGrid.appendChild(card);
  });

  // Attach WhatsApp booking click events to cards
  productGrid.querySelectorAll('.btn-whatsapp-order').forEach(btn => {
    btn.addEventListener('click', () => {
      const prodId = btn.dataset.id;
      const product = allProducts.find(p => p.id === prodId);
      if (product) {
        openBookingModalForProduct(product);
      }
    });
  });

  if (window.lucide) window.lucide.createIcons();
}

/**
 * Render handpicked suggestions / bestsellers
 */
function renderSuggestions() {
  if (!suggestionGrid) return;

  const allProducts = getProducts();
  // Prefer on-sale or highest rated
  const suggestions = allProducts.filter(p => p.onSale || p.rating >= 5).slice(0, 4);

  suggestionGrid.innerHTML = '';
  suggestions.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <div class="product-card-img-wrap" style="height:220px;">
        <img src="${p.img}" alt="${escapeHtml(p.title)}" onerror="this.src='./assets/product_placeholder.jpg'"/>
        ${p.onSale ? '<span class="badge">FEATURED</span>' : ''}
      </div>
      <div class="product-info">
        <h3 style="font-size:0.95rem;">${escapeHtml(p.title)}</h3>
        <div class="price-row">
          <div class="price">${p.price}</div>
          <span style="font-size:0.75rem; color:#888;">${formatCategoryName(p.category)}</span>
        </div>
        <div class="card-actions">
          <button class="btn-whatsapp-order" data-id="${p.id}">
            <i data-lucide="message-circle"></i> Book on WhatsApp
          </button>
        </div>
      </div>
    `;
    suggestionGrid.appendChild(card);
  });

  suggestionGrid.querySelectorAll('.btn-whatsapp-order').forEach(btn => {
    btn.addEventListener('click', () => {
      const prodId = btn.dataset.id;
      const product = allProducts.find(p => p.id === prodId);
      if (product) {
        openBookingModalForProduct(product);
      }
    });
  });

  if (window.lucide) window.lucide.createIcons();
}

/**
 * Setup Category Filtering in Navigation & Footer
 */
function setupCategoryFilters() {
  if (categoryNav) {
    categoryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        activeCategory = link.dataset.cat || 'all';
        updateCategoryNavUI();
        updateCategoryTitle();
        renderCatalog();
      });
    });
  }

  // Footer category links
  document.querySelectorAll('.cat-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      activeCategory = link.dataset.cat || 'all';
      updateCategoryNavUI();
      updateCategoryTitle();
      renderCatalog();
      window.scrollTo({ top: productGrid.offsetTop - 120, behavior: 'smooth' });
    });
  });
}

function updateCategoryNavUI() {
  if (!categoryNav) return;
  categoryNav.querySelectorAll('a').forEach(a => {
    if (a.dataset.cat === activeCategory) {
      a.classList.add('active');
    } else {
      a.classList.remove('active');
    }
  });
}

function updateCategoryTitle() {
  if (!currentCategoryTitle) return;
  const titles = {
    all: 'All Embroidery Collection',
    new: 'New Arrivals 2026',
    unstitched: 'Unstitched Luxury Suits',
    kurtas: 'Embroidered Kurtas & Shirts',
    luxury: 'Luxury Haute Couture Embroidery'
  };
  currentCategoryTitle.textContent = titles[activeCategory] || 'Handcrafted Outfits';
}

/**
 * Live Search Setup
 */
function setupSearch() {
  if (!searchInput) return;

  searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderCatalog();
  });
}

/**
 * WhatsApp Booking Modal Setup
 */
function setupBookingModal() {
  if (btnCloseBookingModal) {
    btnCloseBookingModal.addEventListener('click', closeBookingModal);
  }

  if (bookingModal) {
    bookingModal.addEventListener('click', (e) => {
      if (e.target === bookingModal) closeBookingModal();
    });
  }

  // Custom Booking button in Hero
  if (btnOpenCustomBooking) {
    btnOpenCustomBooking.addEventListener('click', () => {
      openCustomEmbroideryModal();
    });
  }

  // Form submission
  if (bookingForm) {
    bookingForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const customerName = document.getElementById('custName').value.trim();
      const customerPhone = document.getElementById('custPhone').value.trim();
      const quantity = document.getElementById('custQuantity').value;
      const size = document.getElementById('custSize').value;
      const address = document.getElementById('custAddress').value.trim();
      const notes = document.getElementById('custNotes').value.trim();

      const productTitle = formProductTitle.value || 'Custom Embroidery Order';
      const price = formProductPrice.value || 'To be quoted';

      // 1. Record order in local storage so Admin can see it on dashboard
      const orderEntry = {
        customerName,
        customerPhone,
        productTitle,
        price,
        quantity,
        size,
        address,
        notes
      };
      recordOrder(orderEntry);

      // 2. Generate WhatsApp URL to send directly to 03033331383
      const waUrl = buildWhatsAppOrderUrl(orderEntry);

      // 3. Open WhatsApp in new tab
      window.open(waUrl, '_blank');

      // 4. Confirm to user & close modal
      alert(`Thank you, ${customerName}! Your order has been registered and WhatsApp is opening now with your details.`);
      closeBookingModal();
      bookingForm.reset();
    });
  }
}

function openBookingModalForProduct(product) {
  bookingModalHeading.textContent = 'Order on WhatsApp';
  bookingThumb.src = product.img || './assets/product_placeholder.jpg';
  bookingTitle.textContent = product.title;
  bookingPrice.textContent = `Price: ${product.price}`;

  formProductId.value = product.id;
  formProductTitle.value = product.title;
  formProductPrice.value = product.price;

  bookingModal.classList.add('open');
}

function openCustomEmbroideryModal() {
  bookingModalHeading.textContent = 'Bespoke / Custom Embroidery Request';
  bookingThumb.src = './assets/product_placeholder.jpg';
  bookingTitle.textContent = 'Custom Hand/Machine Embroidery Booking';
  bookingPrice.textContent = 'Quotation will be provided on WhatsApp';

  formProductId.value = 'custom_order';
  formProductTitle.value = 'Custom Bespoke Embroidery Work';
  formProductPrice.value = 'Custom Quote';

  bookingModal.classList.add('open');
}

function closeBookingModal() {
  if (bookingModal) bookingModal.classList.remove('open');
}

/**
 * Scroll and UI Effects
 */
function setupScrollEffects() {
  if (!backToTopBtn) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 350) {
      backToTopBtn.classList.add('show');
    } else {
      backToTopBtn.classList.remove('show');
    }
  });

  backToTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/**
 * User & Admin State in Header
 */
function setupUserAuth() {
  updateAuthUI();

  const headerLogoutBtn = document.getElementById('headerLogoutBtn');
  if (headerLogoutBtn) {
    headerLogoutBtn.addEventListener('click', () => {
      logout();
      window.location.reload();
    });
  }
}

function formatCategoryName(cat) {
  switch (cat) {
    case 'new': return 'New Arrival';
    case 'unstitched': return 'Unstitched';
    case 'kurtas': return 'Kurta';
    case 'luxury': return 'Luxury';
    default: return cat;
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
