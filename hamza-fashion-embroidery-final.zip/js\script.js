// script.js – Core storefront interactivity, dynamic catalog & WhatsApp booking for Hamza Fashion Embroidery

import { getProducts, recordOrder } from './products.js';
import { buildWhatsAppOrderUrl, WHATSAPP_NUMBER, runWhenReady } from './utils.js';
import { updateAuthUI, currentUser, logout, isAdmin } from './auth.js';

let activeCategory = 'all';
let searchQuery = '';

// Run reliably whether DOM is still loading or already parsed
runWhenReady(() => {
  initStorefront();
});

function initStorefront() {
  renderCatalog();
  renderSuggestions();
  setupCategoryFilters();
  setupSearch();
  setupBookingModal();
  setupScrollEffects();
  setupUserAuth();

  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    try { window.lucide.createIcons(); } catch(e){}
  }
}

/**
 * Filter and render products to the main product grid
 */
export function renderCatalog() {
  const productGrid = document.getElementById('productGrid');
  const productCountSubtitle = document.getElementById('productCountSubtitle');
  if (!productGrid) return;

  const allProducts = getProducts();
  let filtered = allProducts;

  // Filter by Category
  if (activeCategory !== 'all') {
    filtered = filtered.filter(p => p.category && p.category.toLowerCase() === activeCategory.toLowerCase());
  }

  // Filter by Search Query
  if (searchQuery.trim() !== '') {
    const q = searchQuery.toLowerCase().trim();
    filtered = filtered.filter(p =>
      (p.title && p.title.toLowerCase().includes(q)) ||
      (p.description && p.description.toLowerCase().includes(q)) ||
      (p.category && p.category.toLowerCase().includes(q))
    );
  }

  // Update Section Header Subtitle
  if (productCountSubtitle) {
    productCountSubtitle.textContent = `Showing ${filtered.length} of ${allProducts.length} items in collection`;
  }

  // Clear Grid
  productGrid.innerHTML = '';

  if (filtered.length === 0) {
    productGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 3rem 1rem; color: #888;">
        <i data-lucide="package-search" style="width:48px; height:48px; margin-bottom:1rem; color:#bbb;"></i>
        <h3 style="color:#333; margin-bottom:0.5rem;">No products match your selection</h3>
        <p>Try searching for a different keyword or browse all categories.</p>
        <button id="btnResetSearch" style="margin-top:1rem; padding:0.5rem 1.2rem; background:var(--color-accent); color:#fff; border:none; border-radius:20px; font-weight:600; cursor:pointer;">
          View All Products
        </button>
      </div>
    `;
    const btnReset = document.getElementById('btnResetSearch');
    if (btnReset) {
      btnReset.addEventListener('click', () => {
        activeCategory = 'all';
        searchQuery = '';
        const searchInput = document.getElementById('searchInput');
        if (searchInput) searchInput.value = '';
        updateCategoryNavUI();
        renderCatalog();
      });
    }
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      try { window.lucide.createIcons(); } catch(e){}
    }
    return;
  }

  // Render Product Cards
  filtered.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';

    // Stars HTML
    let starsHtml = '';
    const rating = p.rating || 5;
    for (let i = 1; i <= 5; i++) {
      starsHtml += i <= rating ? '★' : '☆';
    }

    card.innerHTML = `
      <div class="product-card-img-wrap">
        <img src="${p.img}" alt="${escapeHtml(p.title)}" onerror="this.src='./assets/product_placeholder.jpg'"/>
        ${p.onSale ? '<span class="badge">SALE</span>' : ''}
        <span class="category-tag">${formatCategoryName(p.category)}</span>
      </div>

      <div class="product-info">
        <h3>${escapeHtml(p.title)}</h3>
        <p class="product-desc">${escapeHtml(p.description || 'Finest hand & machine embroidery on premium fabric.')}</p>

        <div class="price-row">
          <div class="price">${p.price}</div>
          <div class="rating" title="${rating} of 5 stars">${starsHtml}</div>
        </div>

        <div class="card-actions">
          <button class="btn-whatsapp-order" data-id="${p.id}" title="Order this product on WhatsApp">
            <i data-lucide="message-circle"></i> Order via WhatsApp
          </button>
        </div>
      </div>
    `;

    productGrid.appendChild(card);
  });

  // Attach WhatsApp booking click events to cards
  productGrid.querySelectorAll('.btn-whatsapp-order').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const prodId = btn.dataset.id;
      const product = allProducts.find(p => p.id === prodId);
      if (product) {
        openBookingModalForProduct(product);
      }
    });
  });

  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    try { window.lucide.createIcons(); } catch(e){}
  }
}

/**
 * Render handpicked suggestions / bestsellers
 */
function renderSuggestions() {
  const suggestionGrid = document.getElementById('suggestionGrid');
  if (!suggestionGrid) return;

  const allProducts = getProducts();
  const suggestions = allProducts.filter(p => p.onSale || p.rating >= 5).slice(0, 4);

  suggestionGrid.innerHTML = '';
  suggestions.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <div class="product-card-img-wrap" style="height:220px;">
        <img src="${p.img}" alt="${escapeHtml(p.title)}" onerror="this.src='./assets/product_placeholder.jpg'"/>
        ${p.onSale ? '<span class="badge">FEATURED</span>' : ''}
      </div>
      <div class="product-info">
        <h3 style="font-size:0.95rem;">${escapeHtml(p.title)}</h3>
        <div class="price-row">
          <div class="price">${p.price}</div>
          <span style="font-size:0.75rem; color:#888;">${formatCategoryName(p.category)}</span>
        </div>
        <div class="card-actions">
          <button class="btn-whatsapp-order" data-id="${p.id}">
            <i data-lucide="message-circle"></i> Book on WhatsApp
          </button>
        </div>
      </div>
    `;
    suggestionGrid.appendChild(card);
  });

  suggestionGrid.querySelectorAll('.btn-whatsapp-order').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const prodId = btn.dataset.id;
      const product = allProducts.find(p => p.id === prodId);
      if (product) {
        openBookingModalForProduct(product);
      }
    });
  });

  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    try { window.lucide.createIcons(); } catch(e){}
  }
}

/**
 * Setup Category Filtering in Navigation & Footer
 */
function setupCategoryFilters() {
  const categoryNav = document.getElementById('categoryNav');
  if (categoryNav) {
    categoryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        activeCategory = link.dataset.cat || 'all';
        updateCategoryNavUI();
        updateCategoryTitle();
        renderCatalog();
      });
    });
  }

  // Footer category links
  document.querySelectorAll('.cat-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      activeCategory = link.dataset.cat || 'all';
      updateCategoryNavUI();
      updateCategoryTitle();
      renderCatalog();
      const pGrid = document.getElementById('productGridSection');
      if (pGrid) {
        window.scrollTo({ top: pGrid.offsetTop - 80, behavior: 'smooth' });
      }
    });
  });
}

function updateCategoryNavUI() {
  const categoryNav = document.getElementById('categoryNav');
  if (!categoryNav) return;
  categoryNav.querySelectorAll('a').forEach(a => {
    if (a.dataset.cat === activeCategory) {
      a.classList.add('active');
    } else {
      a.classList.remove('active');
    }
  });
}

function updateCategoryTitle() {
  const currentCategoryTitle = document.getElementById('currentCategoryTitle');
  if (!currentCategoryTitle) return;
  const titles = {
    all: 'All Embroidery Collection',
    new: 'New Arrivals 2026',
    unstitched: 'Unstitched Luxury Suits',
    kurtas: 'Embroidered Kurtas & Shirts',
    luxury: 'Luxury Haute Couture Embroidery'
  };
  currentCategoryTitle.textContent = titles[activeCategory] || 'Handcrafted Outfits';
}

/**
 * Live Search Setup
 */
function setupSearch() {
  const searchInput = document.getElementById('searchInput');
  if (!searchInput) return;

  searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderCatalog();
  });
}

/**
 * WhatsApp Booking Modal Setup
 */
function setupBookingModal() {
  const btnCloseBookingModal = document.getElementById('btnCloseBookingModal');
  const bookingModal = document.getElementById('bookingModal');
  const btnOpenCustomBooking = document.getElementById('btnOpenCustomBooking');
  const bookingForm = document.getElementById('whatsappBookingForm');

  if (btnCloseBookingModal) {
    btnCloseBookingModal.addEventListener('click', closeBookingModal);
  }

  if (bookingModal) {
    bookingModal.addEventListener('click', (e) => {
      if (e.target === bookingModal) closeBookingModal();
    });
  }

  if (btnOpenCustomBooking) {
    btnOpenCustomBooking.addEventListener('click', (e) => {
      e.preventDefault();
      openCustomEmbroideryModal();
    });
  }

  if (bookingForm && !bookingForm.dataset.bound) {
    bookingForm.dataset.bound = 'true';
    bookingForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const customerName = document.getElementById('custName').value.trim();
      const customerPhone = document.getElementById('custPhone').value.trim();
      const quantity = document.getElementById('custQuantity').value;
      const size = document.getElementById('custSize').value;
      const address = document.getElementById('custAddress').value.trim();
      const notes = document.getElementById('custNotes').value.trim();

      const formProductTitle = document.getElementById('formProductTitle');
      const formProductPrice = document.getElementById('formProductPrice');

      const productTitle = (formProductTitle && formProductTitle.value) || 'Custom Embroidery Order';
      const price = (formProductPrice && formProductPrice.value) || 'To be quoted';

      // 1. Record order in local storage so Admin can see it on dashboard
      const orderEntry = {
        customerName,
        customerPhone,
        productTitle,
        price,
        quantity,
        size,
        address,
        notes
      };
      recordOrder(orderEntry);

      // 2. Generate WhatsApp URL to send directly to 03033331383
      const waUrl = buildWhatsAppOrderUrl(orderEntry);

      // 3. Open WhatsApp in new tab
      window.open(waUrl, '_blank');

      // 4. Confirm to user & close modal
      alert(`Thank you, ${customerName}! Your order has been saved and WhatsApp is opening now with your pre-filled details.`);
      closeBookingModal();
      bookingForm.reset();
    });
  }
}

function openBookingModalForProduct(product) {
  const bookingModalHeading = document.getElementById('bookingModalHeading');
  const bookingThumb = document.getElementById('bookingThumb');
  const bookingTitle = document.getElementById('bookingTitle');
  const bookingPrice = document.getElementById('bookingPrice');
  const formProductId = document.getElementById('formProductId');
  const formProductTitle = document.getElementById('formProductTitle');
  const formProductPrice = document.getElementById('formProductPrice');
  const bookingModal = document.getElementById('bookingModal');

  if (bookingModalHeading) bookingModalHeading.textContent = 'Order on WhatsApp';
  if (bookingThumb) bookingThumb.src = product.img || './assets/product_placeholder.jpg';
  if (bookingTitle) bookingTitle.textContent = product.title;
  if (bookingPrice) bookingPrice.textContent = `Price: ${product.price}`;

  if (formProductId) formProductId.value = product.id;
  if (formProductTitle) formProductTitle.value = product.title;
  if (formProductPrice) formProductPrice.value = product.price;

  if (bookingModal) bookingModal.classList.add('open');
}

function openCustomEmbroideryModal() {
  const bookingModalHeading = document.getElementById('bookingModalHeading');
  const bookingThumb = document.getElementById('bookingThumb');
  const bookingTitle = document.getElementById('bookingTitle');
  const bookingPrice = document.getElementById('bookingPrice');
  const formProductId = document.getElementById('formProductId');
  const formProductTitle = document.getElementById('formProductTitle');
  const formProductPrice = document.getElementById('formProductPrice');
  const bookingModal = document.getElementById('bookingModal');

  if (bookingModalHeading) bookingModalHeading.textContent = 'Bespoke / Custom Embroidery Request';
  if (bookingThumb) bookingThumb.src = './assets/product_placeholder.jpg';
  if (bookingTitle) bookingTitle.textContent = 'Custom Hand/Machine Embroidery Booking';
  if (bookingPrice) bookingPrice.textContent = 'Quotation will be provided on WhatsApp';

  if (formProductId) formProductId.value = 'custom_order';
  if (formProductTitle) formProductTitle.value = 'Custom Bespoke Embroidery Work';
  if (formProductPrice) formProductPrice.value = 'Custom Quote';

  if (bookingModal) bookingModal.classList.add('open');
}

function closeBookingModal() {
  const bookingModal = document.getElementById('bookingModal');
  if (bookingModal) bookingModal.classList.remove('open');
}

/**
 * Scroll and UI Effects
 */
function setupScrollEffects() {
  const backToTopBtn = document.getElementById('backToTop');
  if (!backToTopBtn) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 350) {
      backToTopBtn.classList.add('show');
    } else {
      backToTopBtn.classList.remove('show');
    }
  });

  backToTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/**
 * User & Admin State in Header
 */
function setupUserAuth() {
  updateAuthUI();

  const headerLogoutBtn = document.getElementById('headerLogoutBtn');
  if (headerLogoutBtn && !headerLogoutBtn.dataset.bound) {
    headerLogoutBtn.dataset.bound = 'true';
    headerLogoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      logout();
      window.location.reload();
    });
  }
}

function formatCategoryName(cat) {
  switch (cat) {
    case 'new': return 'New Arrival';
    case 'unstitched': return 'Unstitched';
    case 'kurtas': return 'Kurta';
    case 'luxury': return 'Luxury';
    default: return cat || 'Collection';
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
