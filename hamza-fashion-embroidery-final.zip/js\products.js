// products.js – Product and Booking data management for Hamza Fashion Embroidery

import { loadJSON, saveJSON, generateId, formatDate } from './utils.js';

const PRODUCTS_KEY = 'hamza_products';
const ORDERS_KEY = 'hamza_orders';

export const CATEGORIES = [
  { id: 'all', label: 'All Products' },
  { id: 'new', label: 'New Arrivals' },
  { id: 'unstitched', label: 'Unstitched' },
  { id: 'kurtas', label: 'Kurtas' },
  { id: 'luxury', label: 'Luxury Embroidery' }
];

// Initial seed data if no products exist
const DEFAULT_PRODUCTS = [
  {
    id: 'prod_1',
    title: 'Royal Maroon Embroidered Kurta',
    category: 'kurtas',
    price: 'Rs. 4,999',
    img: './assets/product_placeholder.jpg',
    rating: 5,
    onSale: true,
    description: 'Intricately embroidered neckline with fine tilla threadwork on premium wash-and-wear fabric.',
    createdAt: '2026-11-20T10:00:00.000Z'
  },
  {
    id: 'prod_2',
    title: 'Classic Unstitched Embroidered Suit (3-Pc)',
    category: 'unstitched',
    price: 'Rs. 3,899',
    img: './assets/product_placeholder.jpg',
    rating: 4,
    onSale: false,
    description: 'Pure lawn embroidered front with dyed cambric trouser and digital printed dupatta.',
    createdAt: '2026-11-21T11:30:00.000Z'
  },
  {
    id: 'prod_3',
    title: 'Luxury Velvet Zari & Dabka Embroidery Shawl',
    category: 'luxury',
    price: 'Rs. 6,499',
    img: './assets/product_placeholder.jpg',
    rating: 5,
    onSale: true,
    description: 'Heavy borders with hand-crafted zari, dabka and sequence work on micro-velvet fabric.',
    createdAt: '2026-11-22T09:15:00.000Z'
  },
  {
    id: 'prod_4',
    title: 'Festive Chikankari Embroidered Kurta',
    category: 'new',
    price: 'Rs. 4,299',
    img: './assets/product_placeholder.jpg',
    rating: 5,
    onSale: false,
    description: 'Delicate summer chikankari embroidery with pearl embellishments on soft premium cotton.',
    createdAt: '2026-11-23T14:45:00.000Z'
  },
  {
    id: 'prod_5',
    title: 'Handcrafted Mirror-Work Short Kurti',
    category: 'kurtas',
    price: 'Rs. 2,999',
    img: './assets/product_placeholder.jpg',
    rating: 4,
    onSale: false,
    description: 'Traditional mirror embroidery on sleeves and daman with contemporary cut.',
    createdAt: '2026-11-23T16:00:00.000Z'
  },
  {
    id: 'prod_6',
    title: 'Bridal Heritage Embroidered Raw Silk Dupatta',
    category: 'luxury',
    price: 'Rs. 7,999',
    img: './assets/product_placeholder.jpg',
    rating: 5,
    onSale: true,
    description: 'Extensive hand embroidery with antique gold embellishments on pure raw silk.',
    createdAt: '2026-11-24T08:30:00.000Z'
  }
];

/**
 * Get all products. Seeds defaults on first run.
 */
export function getProducts() {
  let products = loadJSON(PRODUCTS_KEY);
  if (!products || !Array.isArray(products) || products.length === 0) {
    products = DEFAULT_PRODUCTS;
    saveJSON(PRODUCTS_KEY, products);
  }
  return products;
}

/**
 * Get single product by id
 */
export function getProductById(id) {
  const products = getProducts();
  return products.find(p => p.id === id) || null;
}

/**
 * Save / Create a new product (Admin)
 */
export function addProduct(productData) {
  const products = getProducts();
  const newProduct = {
    id: generateId('prod'),
    title: productData.title.trim(),
    category: productData.category || 'new',
    price: productData.price.startsWith('Rs.') ? productData.price : `Rs. ${productData.price.replace(/[^\d,]/g, '') || '0'}`,
    img: productData.img?.trim() || './assets/product_placeholder.jpg',
    rating: Number(productData.rating) || 5,
    onSale: Boolean(productData.onSale),
    description: productData.description?.trim() || '',
    createdAt: new Date().toISOString()
  };

  products.unshift(newProduct);
  saveJSON(PRODUCTS_KEY, products);
  return newProduct;
}

/**
 * Update an existing product (Admin)
 */
export function updateProduct(id, productData) {
  const products = getProducts();
  const index = products.findIndex(p => p.id === id);
  if (index === -1) return null;

  const existing = products[index];
  const updatedPrice = productData.price.startsWith('Rs.')
    ? productData.price
    : `Rs. ${productData.price.replace(/[^\d,]/g, '') || existing.price}`;

  const updatedProduct = {
    ...existing,
    title: productData.title.trim(),
    category: productData.category || existing.category,
    price: updatedPrice,
    img: productData.img?.trim() || existing.img || './assets/product_placeholder.jpg',
    rating: Number(productData.rating) || existing.rating,
    onSale: Boolean(productData.onSale),
    description: productData.description?.trim() || existing.description,
    updatedAt: new Date().toISOString()
  };

  products[index] = updatedProduct;
  saveJSON(PRODUCTS_KEY, products);
  return updatedProduct;
}

/**
 * Delete a product (Admin)
 */
export function deleteProduct(id) {
  const products = getProducts();
  const filtered = products.filter(p => p.id !== id);
  saveJSON(PRODUCTS_KEY, filtered);
  return filtered;
}

/**
 * Reset products back to default seeds (Admin convenience)
 */
export function resetDefaultProducts() {
  saveJSON(PRODUCTS_KEY, DEFAULT_PRODUCTS);
  return DEFAULT_PRODUCTS;
}

// ---------------- BOOKINGS / ORDERS ---------------- //

/**
 * Get all customer WhatsApp bookings/orders
 */
export function getOrders() {
  return loadJSON(ORDERS_KEY) || [];
}

/**
 * Add a new order when customer books through WhatsApp form
 */
export function recordOrder(orderData) {
  const orders = getOrders();
  const newOrder = {
    id: generateId('order'),
    ...orderData,
    date: formatDate(new Date()),
    timestamp: new Date().toISOString()
  };
  orders.unshift(newOrder);
  saveJSON(ORDERS_KEY, orders);
  return newOrder;
}

/**
 * Delete order from dashboard
 */
export function deleteOrder(id) {
  const orders = getOrders();
  const filtered = orders.filter(o => o.id !== id);
  saveJSON(ORDERS_KEY, filtered);
  return filtered;
}
